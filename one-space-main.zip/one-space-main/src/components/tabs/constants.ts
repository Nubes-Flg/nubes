export const SECTION_TYPE = {
  HOME: "Home",
  ABOUT: "About",
  PROJECTS: "Projects",
  BLOGS: "Blogs",
  STACK: "Stack"
}
