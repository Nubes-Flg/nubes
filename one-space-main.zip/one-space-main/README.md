<h1 align="center">
  <span>One Space</span>
</h1>

<div align="center">
  <a href="https://github.com/LHRUN/one-space/blob/main/LICENSE">
    <img src="https://img.shields.io/github/license/LHRUN/bubble" alt="License Badge"/>
  </a>
  <a href="https://github.com/LHRUN/one-space">
    <img src="https://img.shields.io/badge/Made%20with-Next%20%26%20Three-pink" alt="Next&Three" />
  </a>
  <a href="https://github.com/LHRUN/one-space">
    <img src="https://img.shields.io/badge/Deploy-Vercel-red" alt="deploy" />
  </a>
</div>

One Space is a personal space page dedicated to showing yourself, if you feel good welcome Star ⭐️, thanks!

One Space 是一个专门用于展示自己的个人空间页, 如果感觉不错的话欢迎 Star ⭐️, 感谢支持!

link: [https://about.songlh.top/](https://about.songlh.top/)

![](https://raw.githubusercontent.com/LHRUN/file-store/refs/heads/main/post/one-space-1.1.0.png)


+ Model
  - [Portrait of a Man](https://threedscans.com/uncategorized/portrait-of-a-man/)

+ Font
  - [Monoton](https://www.googlefonts.cn/specimen/Monoton)
  - [Bree Serif](https://www.googlefonts.cn/specimen/Bree+Serif)

